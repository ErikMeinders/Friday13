"""Utility functions for detecting repeating patterns in sequences."""

from .find_repeat import find_repeat

__version__ = "0.1.0"
